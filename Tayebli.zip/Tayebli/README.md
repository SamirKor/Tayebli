# TAYEBLI

All across the world people of all ages need to eat healthy food.
And we all come to a point where we don't know what to cook or have a lack of ingredients.
Here come TAYEBLI a website that provide recipes for people based on their ingredients.


# Services

Our website should provide a warm design with all the following services to help our dear visitors:

-**User account**: every user can create an account with which he can:
 -*post his own recipes*: a user can post his recipes with a description,  ingredients, a step by step guide and photos to show the meal.
 -*comment, leave a review and add the recipe to his favorites list*.

-**Smart Suggestion**: a way that suggest meal and recipes based on the time of the day accesing the time zone of the user.

-**"Fridge"**: every user can have a virtual fridge that he can fill with the ingredients that he have in his house which will help providing more suitable suggestions in the home page.

-**Search**: a searching algorithm that provide recipes based on the ingredients entered by the user.

-**Planner**:
 -*Manual*: where the user himself fill a weekly planner based on his preferences.
 -*Heathy*: where a palanner is given to the user based on what he's planning to do(a diet, bulking..etc). (Requires some kind of AI so we're not sure if we'll be able to implement it)

-**Settings**:
  -provide to the user the ability to change his infos and add restrictions to the suggetions (vegan, gluten free...)
  -general prefrences selector (time sprent in the recipes, difficulty ...)


# Tasks:

-Kadi Sami Youcef:
  -Search system/page
  -Suggestions based on time zone systme/page
  -favorites page
  -comments, add to favorites, rating...etc.

-Korbas Samir Abdelhakim:
  -home page
  -navbar and footer
  -postion recipes form/page
  -login-signup form/page
  -weekly planner page (manual)

-Merdj Abdelhak:
  -user settings
  -the discription page for recipes

additional tasks(work together):
  -the "fridge".
  -the "healthy" planner.
  

